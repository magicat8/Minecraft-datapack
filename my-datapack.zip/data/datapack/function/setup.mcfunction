# datapack:setup
# Runs when called with: /function datapack:setup

say Hello from the datapack datapack
tellraw @a {"text":"setup ran","color":"green"}